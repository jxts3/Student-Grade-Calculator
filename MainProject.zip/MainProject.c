#include <stdio.h>

#define MAX_ASSIGNMENTS 100

typedef struct {
    char name[50];
    float score;
    float total;
    float weight;
} Assignment;

void getAssignments(Assignment assignments[], int *numAssignments){
    printf("Enter the number of assignments: ");
    scanf("%d", numAssignments);

    if(*numAssignments <= 0 || *numAssignments > MAX_ASSIGNMENTS){
        printf("Invalid number of assignments! Please enter a valid number.\n");
        return;
    }

    for (int i = 0; i < *numAssignments; i++) {
        printf("\nEnter details for assignment %d:\n", i + 1);

        printf("Name: ");
        scanf(" %[^\n]", assignments[i].name);

        printf("Score earned: ");
        scanf("%f", &assignments[i].score);

        printf("Total points possible: ");
        scanf("%f", &assignments[i].total);

        printf("Weight (percentage): ");
        scanf("%f", &assignments[i].weight);

        if(assignments[i].score > assignments[i].total || assignments[i].weight < 0){
            printf("Invalid input! Score cannot exceed total points, and weight must be positive.\n");
            i--;
        }
    }
}
float calculateFinalGrade(Assignment assignments[], int numAssignments) {
    float finalGrade = 0;

    for (int i = 0; i < numAssignments; i++){
        float weightedScore = (assignments[i].score / assignments[i].total) * assignments[i].weight;
        finalGrade += weightedScore;
    }

    return finalGrade;
}

char getLetterGrade(float finalGrade){
    if (finalGrade >= 90) return 'A';
    else if (finalGrade >= 80) return 'B';
    else if (finalGrade >= 70) return 'C';
    else if (finalGrade >= 60) return 'D';
    else return 'F';
}

void displayFinalResults(Assignment assignments[], int numAssignments, float finalGrade){
    printf("\nFinal Grade Summary:\n");
    printf("---------------------------------------------------\n");

    for(int i = 0; i < numAssignments; i++) {
        printf("%s: %.2f/%.2f (Weight: %.2f%%)\n", assignments[i].name, assignments[i].score, assignments[i].total, assignments[i].weight);
    }
    printf("\nTotal Weighted Score: %.2f\n", finalGrade);
    printf("Final Grade Percentage: %.2f%%\n", finalGrade);
    printf("Letter Grade: %c\n", getLetterGrade(finalGrade));
}

int main() {
    Assignment assignments[MAX_ASSIGNMENTS];
    int numAssignments;

    getAssignments(assignments, &numAssignments);

    if (numAssignments > 0){
        float finalGrade = calculateFinalGrade(assignments, numAssignments);
        displayFinalResults(assignments, numAssignments, finalGrade);
    } else {
        printf("No valid assignments entered.\n");
    }

    return 0;
}
